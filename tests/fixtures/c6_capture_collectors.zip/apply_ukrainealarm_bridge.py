#!/usr/bin/env python3
from __future__ import annotations

import base64
import csv
import gzip
import io
import json
import os
import re
import time
from datetime import date, datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import requests

from ukrainealarm_request_policy import (
    UkraineAlarmClient,
    UkraineAlarmAuthenticationError,
    UkraineAlarmRateLimitExhausted,
    UkraineAlarmRetryBudgetExceeded,
)
import multicity_shadow_payload
import add_duration_unit_switch as exactmod
import expand_multicity_production as base
import extend_remaining_proxies as extended
from update_data import Alert, TZ, build_outputs
from db_phase1_lviv_canonical import canonicalize_lviv, ukrainealarm_rows_to_observations

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "dashboard_data.json"
STORE_FILE = ROOT / "data" / "ukrainealarm_bridge.json"
STATIC_BRIDGES = [
    ROOT / "data" / "alerts_in_ua_bridge_2026-09-07_16.csv.gz.b64",
    ROOT / "data" / "alerts_in_ua_bridge_additional_2026-09-07_16.csv.gz.b64",
]
STATIC_METAS = [
    ROOT / "data" / "alerts_in_ua_bridge_2026-09-07_16.meta.json",
    ROOT / "data" / "alerts_in_ua_bridge_additional_2026-09-07_16.meta.json",
]
API_BASE = "https://api.ukrainealarm.com/api/v3"
REGIONS_URL = f"{API_BASE}/regions"
HISTORY_URL = f"{API_BASE}/alerts/regionHistory"
TOKEN_ENV = "UKRAINEALARM_API_TOKEN"
UTC = timezone.utc
MATCH_TOLERANCE_SECONDS = 15.0
MIN_API_INTERVAL_SECONDS = max(70.0, float(os.getenv("UKRAINEALARM_MIN_INTERVAL_SECONDS", "70")))
MAX_401_RETRIES = 2
STORE_SCHEMA_VERSION = 3

EXACT_OBLAST = {
    "kharkiv": "Харківська область",
    "zaporizhzhia": "Запорізька область",
}
EXACT_ALIASES = {
    "kharkiv": [
        "м. Харків та Харківська територіальна громада",
        "Харківська територіальна громада",
        "Харківська міська територіальна громада",
        "м. Харків",
        "Харків",
    ],
    "zaporizhzhia": [
        "м. Запоріжжя та Запорізька територіальна громада",
        "Запорізька територіальна громада",
        "Запорізька міська територіальна громада",
        "м. Запоріжжя",
        "Запоріжжя",
    ],
}


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    text = str(value).strip().replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        if "." not in text:
            return None
        head, tail = text.split(".", 1)
        offset = ""
        for i, ch in enumerate(tail):
            if i and ch in "+-":
                offset, tail = tail[i:], tail[:i]
                break
        digits = "".join(ch for ch in tail if ch.isdigit())[:6]
        try:
            dt = datetime.fromisoformat(f"{head}.{digits}{offset}")
        except ValueError:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def iso(dt: datetime | None) -> str | None:
    return dt.astimezone(UTC).isoformat().replace("+00:00", "Z") if dt else None


def norm(value: str) -> str:
    return " ".join(str(value).casefold().replace("’", "'").split())


def load_static_bridge() -> tuple[dict[str, list[Alert]], dict]:
    rows: dict[str, list[Alert]] = {}
    metas = []
    for payload_path, meta_path in zip(STATIC_BRIDGES, STATIC_METAS):
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        metas.append(meta)
        raw = gzip.decompress(
            base64.b64decode(payload_path.read_text(encoding="ascii").strip())
        ).decode("utf-8")
        for row in csv.DictReader(io.StringIO(raw)):
            key = (row.get("city_key") or "").strip()
            start = parse_dt(row.get("start"))
            end = parse_dt(row.get("end"))
            if key and start and end and end > start:
                rows.setdefault(key, []).append(
                    Alert(
                        start=start.astimezone(TZ),
                        end=end.astimezone(TZ),
                        source="alerts_in_ua_static_bridge",
                    )
                )
    for key, alerts in rows.items():
        unique = {(a.start, a.end): a for a in alerts}
        rows[key] = sorted(unique.values(), key=lambda a: a.start)

    starts = [parse_dt(m.get("coverage_start")) for m in metas]
    ends = [parse_dt(m.get("coverage_end_exclusive")) for m in metas]
    if any(x is None for x in [*starts, *ends]):
        raise RuntimeError("Invalid static bridge coverage metadata")
    info = {
        "source": "Alerts.in.ua manual CSV export",
        "coverage_start": iso(min(x for x in starts if x)),
        "coverage_end_exclusive": iso(max(x for x in ends if x)),
        "payload_files": [p.name for p in STATIC_BRIDGES],
        "completed_event_rows": sum(len(v) for v in rows.values()),
        "cross_source_match_tolerance_seconds": MATCH_TOLERANCE_SECONDS,
    }
    return rows, info


def load_store() -> dict:
    if not STORE_FILE.exists():
        return {
            "schema_version": STORE_SCHEMA_VERSION,
            "source_url": HISTORY_URL,
            "regions": {},
            "events": [],
        }
    try:
        store = json.loads(STORE_FILE.read_text(encoding="utf-8"))
    except Exception:
        store = {}
    if store.get("schema_version") != STORE_SCHEMA_VERSION:
        return {
            "schema_version": STORE_SCHEMA_VERSION,
            "source_url": HISTORY_URL,
            "regions": {},
            "events": [],
            "reset_from_schema_version": store.get("schema_version"),
        }
    store.setdefault("regions", {})
    store.setdefault("events", [])
    store.setdefault("source_url", HISTORY_URL)
    return store


def collect_nodes(payload) -> list[dict]:
    nodes: list[dict] = []
    seen = set()

    def walk(value, ancestors=()):
        if isinstance(value, list):
            for item in value:
                walk(item, ancestors)
            return
        if not isinstance(value, dict):
            return
        rid = value.get("regionId")
        name = str(value.get("regionName") or "").strip()
        child_ancestors = ancestors
        if rid is not None and name:
            marker = (str(rid), name)
            if marker not in seen:
                seen.add(marker)
                nodes.append(
                    {
                        "regionId": str(rid),
                        "regionName": name,
                        "regionType": value.get("regionType"),
                        "ancestors": list(ancestors),
                    }
                )
            child_ancestors = (*ancestors, name)
        for child in value.values():
            if isinstance(child, (dict, list)):
                walk(child, child_ancestors)

    walk(payload)
    return nodes


def resolve_region(nodes: list[dict], names: list[str], oblast: str) -> dict | None:
    wanted = {norm(x) for x in names}
    matches = [n for n in nodes if norm(n["regionName"]) in wanted]
    oblast_norm = norm(oblast)
    scoped = [
        n
        for n in matches
        if oblast_norm in {norm(a) for a in n.get("ancestors", [])}
        or norm(n["regionName"]) == oblast_norm
    ]
    if scoped:
        matches = scoped
    if not matches:
        return None
    matches.sort(key=lambda n: (len(n.get("ancestors", [])), n["regionId"]))
    return matches[-1]


def history_rows(client: UkraineAlarmClient, region_id: str, name: str) -> list[dict]:
    response = client.get(
        HISTORY_URL,
        params={"regionId": region_id},
        context=f"regionHistory {name} ({region_id})",
    )
    payload = response.json()
    groups = [payload] if isinstance(payload, dict) else [x for x in payload if isinstance(x, dict)]
    rows = []
    for group in groups:
        for alarm in group.get("alarms") or []:
            if not isinstance(alarm, dict):
                continue
            if str(alarm.get("alertType") or "").upper() != "AIR":
                continue
            start = parse_dt(alarm.get("startDate"))
            end = parse_dt(alarm.get("endDate"))
            if start and end and end > start:
                rows.append({"start": start, "end": end})
    unique = {(r["start"], r["end"]): r for r in rows}
    return sorted(unique.values(), key=lambda r: r["start"])



def history_events(
    history: list[dict],
    *,
    city_key: str,
    region_id: str,
    api_region_name: str,
) -> list[dict]:
    return [
        {
            "city_key": city_key,
            "region_id": region_id,
            "api_region_name": api_region_name,
            "start": iso(row["start"]),
            "end": iso(row["end"]),
            "alert_type": "AIR",
        }
        for row in history
    ]


def lviv_phase1_observations_from_history(
    history: list[dict],
    *,
    region_id: str,
    api_region_name: str,
) -> list[dict]:
    return ukrainealarm_rows_to_observations(
        history_events(
            history,
            city_key="lviv",
            region_id=region_id,
            api_region_name=api_region_name,
        ),
        historical_end_exclusive=None,
    )


def _completed_air_times(event: dict) -> tuple[datetime, datetime] | None:
    if str(event.get("alert_type") or "").upper() != "AIR":
        return None
    start = parse_dt(event.get("start"))
    end = parse_dt(event.get("end"))
    if not event.get("city_key") or start is None or end is None or end <= start:
        return None
    return start, end


def _manual_recovery_event(event: dict) -> bool:
    return bool(
        event.get("source") == "alerts.in.ua_manual_csv_recovery"
        or event.get("source_kind") == "manual_csv_export"
    )


def _events_equivalent(a: dict, b: dict) -> bool:
    if a.get("city_key") != b.get("city_key"):
        return False
    a_times = _completed_air_times(a)
    b_times = _completed_air_times(b)
    if a_times is None or b_times is None:
        return False
    return (
        abs((a_times[0] - b_times[0]).total_seconds()) <= MATCH_TOLERANCE_SECONDS
        and abs((a_times[1] - b_times[1]).total_seconds()) <= MATCH_TOLERANCE_SECONDS
    )


def _recovery_provenance(event: dict) -> dict:
    return {
        "original_recovery_source": event.get("source"),
        "source_kind": event.get("source_kind"),
        "source_files": list(event.get("source_files") or []),
        "recovery_artifact": event.get("recovery_artifact"),
        "original_recovery_start": event.get("start"),
        "original_recovery_end": event.get("end"),
    }


def _merge_equivalent_events(existing: dict, incoming: dict) -> dict:
    existing_manual = _manual_recovery_event(existing)
    incoming_manual = _manual_recovery_event(incoming)

    if existing_manual != incoming_manual:
        manual = existing if existing_manual else incoming
        api = incoming if existing_manual else existing
        merged = dict(api)
        merged["recovery_provenance"] = _recovery_provenance(manual)
        return merged

    merged = dict(existing)
    if not existing_manual:
        merged.update(incoming)
        if existing.get("recovery_provenance") and not incoming.get("recovery_provenance"):
            merged["recovery_provenance"] = existing["recovery_provenance"]
    return merged


def _find_equivalent_event_index(events: list[dict], event: dict) -> int | None:
    exact_key = (event.get("city_key"), event.get("start"), event.get("end"))
    for index, existing in enumerate(events):
        if (existing.get("city_key"), existing.get("start"), existing.get("end")) == exact_key:
            return index
    for index, existing in enumerate(events):
        if _events_equivalent(existing, event):
            return index
    return None


def reconcile_completed_air_events(rows: list[dict]) -> list[dict]:
    reconciled: list[dict] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        event = dict(row)
        index = _find_equivalent_event_index(reconciled, event)
        if index is None:
            reconciled.append(event)
        else:
            reconciled[index] = _merge_equivalent_events(reconciled[index], event)
    return reconciled


def upsert_completed_air_event(events: list[dict], event: dict) -> None:
    index = _find_equivalent_event_index(events, event)
    if index is None:
        events.append(dict(event))
    else:
        events[index] = _merge_equivalent_events(events[index], event)



def match_static_event(api_rows: list[dict], static_rows: list[Alert]) -> dict | None:
    for api in api_rows:
        for bridge in static_rows:
            ds = abs((api["start"] - bridge.start.astimezone(UTC)).total_seconds())
            de = abs((api["end"] - bridge.end.astimezone(UTC)).total_seconds())
            if ds <= MATCH_TOLERANCE_SECONDS and de <= MATCH_TOLERANCE_SECONDS:
                return {
                    "api_start": iso(api["start"]),
                    "api_end": iso(api["end"]),
                    "static_start": bridge.start.isoformat(),
                    "static_end": bridge.end.isoformat(),
                    "start_delta_seconds": round(ds, 3),
                    "end_delta_seconds": round(de, 3),
                }
    return None


def union_alerts(alerts: list[Alert], source: str) -> list[Alert]:
    merged: list[list[datetime]] = []
    for alert in sorted(alerts, key=lambda a: a.start):
        if not merged or alert.start > merged[-1][1]:
            merged.append([alert.start, alert.end])
        elif alert.end > merged[-1][1]:
            merged[-1][1] = alert.end
    return [Alert(start=s, end=e, source=source) for s, e in merged]


def generic_comparison(cities: dict, keys: list[str], period: str) -> list[dict]:
    by_city = {key: {row["time"]: row for row in cities[key].get(period, [])} for key in keys}
    if not keys:
        return []
    shared = set(by_city[keys[0]])
    for key in keys[1:]:
        shared &= set(by_city[key])
    out = []
    for timestamp in sorted(shared):
        row = {"time": timestamp}
        for key in keys:
            src = by_city[key][timestamp]
            row[f"{key}_alerts_per_day"] = src.get("alerts_per_day")
            row[f"{key}_avg_daily_alert_hours"] = src.get("avg_daily_alert_hours")
            row[f"{key}_avg_alert_duration_min"] = src.get("avg_alert_duration_min")
        out.append(row)
    return out


def api_store_alerts(store: dict, key: str) -> list[Alert]:
    out = []
    for row in store.get("events", []):
        if row.get("city_key") != key:
            continue
        start = parse_dt(row.get("start"))
        end = parse_dt(row.get("end"))
        if start and end and end > start:
            out.append(
                Alert(
                    start=start.astimezone(TZ),
                    end=end.astimezone(TZ),
                    source="ukrainealarm_official_api_bridge",
                )
            )
    return sorted(out, key=lambda a: a.start)


def specs(proxy_cfg: dict[str, dict]) -> dict[str, dict]:
    out = {}
    for key, cfg in exactmod.CITY_CONFIG.items():
        out[key] = {
            "kind": "exact",
            "names": EXACT_ALIASES[key],
            "oblast": EXACT_OBLAST[key],
            "display_target": cfg["hromada"],
        }
    for key, cfg in proxy_cfg.items():
        out[key] = {
            "kind": "proxy",
            "names": [cfg["raion"]],
            "oblast": cfg["oblast"],
            "display_target": cfg["raion"],
        }
    return out


def phase1_db_shadow_enabled(env=None) -> bool:
    source_env = os.environ if env is None else env
    return str(source_env.get("PHASE1_DB_SHADOW", "0")).strip() == "1"


_SHADOW_FAILURE_POLICIES = {"fail_closed", "fail_open"}
_SHADOW_SENSITIVE_ENV_KEYS = (
    "PHASE1_DATABASE_URL",
    "PHASE1_PROD_SHADOW_DATABASE_URL",
    "NEON_API_KEY",
    "UKRAINEALARM_API_TOKEN",
)


def phase1_db_shadow_failure_policy(env=None) -> str:
    source_env = os.environ if env is None else env
    policy = str(
        source_env.get("PHASE1_DB_SHADOW_FAILURE_POLICY", "fail_closed")
    ).strip()
    if policy not in _SHADOW_FAILURE_POLICIES:
        raise RuntimeError(
            "PHASE1_DB_SHADOW_FAILURE_POLICY must be one of: fail_closed, fail_open"
        )
    return policy


def _sanitize_shadow_error_message(exc: Exception, env) -> str:
    message = str(exc)
    for key in _SHADOW_SENSITIVE_ENV_KEYS:
        value = str(env.get(key) or "").strip()
        if not value:
            continue
        candidates = [value]
        if key in {"PHASE1_DATABASE_URL", "PHASE1_PROD_SHADOW_DATABASE_URL"}:
            try:
                parsed = urlsplit(value)
                if parsed.password:
                    candidates.append(parsed.password)
            except ValueError:
                pass
        for candidate in sorted(set(candidates), key=len, reverse=True):
            if candidate:
                message = message.replace(candidate, "[REDACTED]")
    message = re.sub(
        r"(?i)postgres(?:ql)?://[^\\s'\\\"]+",
        "postgresql://[REDACTED]",
        message,
    )
    return message[:2000]


def _write_shadow_diagnostic(payload: dict, env) -> None:
    path = str(env.get("PHASE1_DB_SHADOW_DIAGNOSTIC") or "").strip()
    if not path:
        return
    raw = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    for key in _SHADOW_SENSITIVE_ENV_KEYS:
        value = str(env.get(key) or "").strip()
        if value and value in raw:
            raise RuntimeError(
                f"refusing to write Phase-1 shadow diagnostic containing {key}"
            )
        if key in {"PHASE1_DATABASE_URL", "PHASE1_PROD_SHADOW_DATABASE_URL"} and value:
            try:
                password = urlsplit(value).password
            except ValueError:
                password = None
            if password and password in raw:
                raise RuntimeError(
                    "refusing to write Phase-1 shadow diagnostic containing DB password"
                )
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(raw, encoding="utf-8")


def _shadow_success_diagnostic(result: dict, env, policy: str) -> dict:
    stats = dict(result.get("stats") or {})
    return {
        "shadow_enabled": True,
        "failure_policy": policy,
        "status": "succeeded",
        "db_branch": str(env.get("PHASE1_DB_BRANCH") or "").strip() or None,
        "run_id": result.get("run_id"),
        "checkpoint_id": result.get("checkpoint_id"),
        "checkpoint_seq": result.get("checkpoint_seq"),
        "episodes_inserted": int(stats.get("episodes_inserted", 0)),
        "episodes_existing": int(stats.get("episodes_existing", 0)),
        "source_observations_inserted": int(
            stats.get("source_observations_inserted", 0)
        ),
        "source_observations_existing": int(
            stats.get("source_observations_existing", 0)
        ),
        "source_observations_last_seen_updated": int(
            stats.get("source_observations_last_seen_updated", 0)
        ),
        "checkpoints_inserted": int(stats.get("checkpoints_inserted", 0)),
        "exact_retry": bool(stats.get("exact_retry", False)),
        "workflow_sha": result.get("workflow_sha")
        or str(env.get("GITHUB_SHA") or "").strip()
        or None,
        "input_sha": result.get("input_sha")
        or str(env.get("PHASE1_INPUT_SHA") or "").strip()
        or str(env.get("GITHUB_SHA") or "").strip()
        or None,
        "credentials_exposed": False,
    }


def _shadow_failure_diagnostic(exc: Exception, env, policy: str) -> dict:
    return {
        "shadow_enabled": True,
        "failure_policy": policy,
        "status": "failed",
        "error_type": type(exc).__name__,
        "sanitized_error_message": _sanitize_shadow_error_message(exc, env),
        "workflow_sha": str(env.get("GITHUB_SHA") or "").strip() or None,
        "input_sha": str(env.get("PHASE1_INPUT_SHA") or "").strip()
        or str(env.get("GITHUB_SHA") or "").strip()
        or None,
        "db_branch": str(env.get("PHASE1_DB_BRANCH") or "").strip() or None,
        "credentials_exposed": False,
    }


def persist_lviv_shadow_if_enabled(
    *,
    lviv_fetched_this_run: bool,
    vadimkin_observations: list[dict],
    ukrainealarm_observations: list[dict],
    checkpoint_state: dict | None,
    env=None,
):
    source_env = os.environ if env is None else env
    if not phase1_db_shadow_enabled(source_env):
        return None

    policy = phase1_db_shadow_failure_policy(source_env)
    try:
        missing = []
        if not lviv_fetched_this_run:
            missing.append("current Lviv UkraineAlarm fetch")
        if not vadimkin_observations:
            missing.append("current-run Vadimkin observations")
        if not ukrainealarm_observations:
            missing.append("current-run UkraineAlarm observations")
        state = checkpoint_state or {}
        region_id = str(state.get("region_id") or "").strip()
        if not region_id:
            missing.append("resolved Lviv region_id")
        if not bool(state.get("continuous")):
            missing.append("verified Lviv continuity")
        if missing:
            raise RuntimeError(
                "PHASE1_DB_SHADOW=1 requires fresh verified Lviv inputs: "
                + ", ".join(missing)
            )

        ua_region_ids = {
            str((observation.get("provenance") or {}).get("region_id") or "")
            for observation in ukrainealarm_observations
        }
        if ua_region_ids != {region_id}:
            raise RuntimeError(
                "PHASE1_DB_SHADOW=1 Lviv UkraineAlarm observations do not match "
                f"resolved region_id={region_id}: {sorted(ua_region_ids)}"
            )

        canonical_payload = canonicalize_lviv(
            vadimkin_observations,
            ukrainealarm_observations,
            checkpoint_state=state,
        )
        if canonical_payload.get("boundary_errors"):
            raise RuntimeError(
                "PHASE1_DB_SHADOW=1 canonical boundary errors: "
                f"{canonical_payload['boundary_errors']}"
            )
        source_keys = [
            str(observation.get("source_key") or "")
            for observation in canonical_payload.get("source_observations", [])
        ]
        if any(
            key == "alerts-in-ua" or key.startswith("alerts_in_ua")
            for key in source_keys
        ):
            raise RuntimeError(
                "Alerts.in.ua must not become a Phase-1 canonical source observation"
            )

        # Deliberately late: shadow OFF must not require the DB adapter or psycopg.
        from db_phase1_shadow import persist_shadow_payload

        result = persist_shadow_payload(
            canonical_payload,
            checkpoint_state=state,
            env=source_env,
        )
        _write_shadow_diagnostic(
            _shadow_success_diagnostic(result, source_env, policy),
            source_env,
        )
        return result
    except Exception as exc:
        diagnostic = _shadow_failure_diagnostic(exc, source_env, policy)
        try:
            _write_shadow_diagnostic(diagnostic, source_env)
        except Exception as diagnostic_exc:
            print(
                "Phase-1 DB shadow diagnostic write failed: "
                f"{type(diagnostic_exc).__name__}: "
                f"{_sanitize_shadow_error_message(diagnostic_exc, source_env)}",
                flush=True,
            )
        if policy == "fail_open":
            print(
                "Phase-1 DB shadow failed open: "
                f"{diagnostic['error_type']}: "
                f"{diagnostic['sanitized_error_message']}",
                flush=True,
            )
            return None
        raise

def main() -> None:
    data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    cities = data.setdefault("cities", {})
    mm = data.setdefault("multicity_meta", {})
    token = os.getenv(TOKEN_ENV, "").strip()
    static, static_info = load_static_bridge()

    proxy_cfg = extended.configure_all_proxies()
    target_specs = specs(proxy_cfg)
    required_keys = list(target_specs)
    missing_static = [key for key in required_keys if not static.get(key)]
    if missing_static:
        raise RuntimeError(f"Static bridge has no completed events for: {missing_static}")

    exact_base = exactmod.fetch_city_alerts()
    proxy_base, lviv_vadimkin_observations = base.fetch_proxy_alerts_with_phase1()
    lviv_ukrainealarm_observations: list[dict] = []
    lviv_checkpoint_state: dict | None = None
    lviv_fetched_this_run = False
    store = load_store()
    store["static_bridge"] = static_info
    store["match_tolerance_seconds"] = MATCH_TOLERANCE_SECONDS
    attempt_at = datetime.now(UTC)
    store["last_attempt_at"] = iso(attempt_at)

    events = reconcile_completed_air_events(store.get("events", []))
    request_errors: dict[str, str] = {}
    fetched_keys: list[str] = []

    if token:
        client = UkraineAlarmClient(
            token,
            capture_diagnostic_path=os.getenv("DIFFERENTIATED_ALERT_SOURCE_CAPTURE_DIAGNOSTIC"),
            min_interval=MIN_API_INTERVAL_SECONDS,
        )
        nodes: list[dict] | None = None
        unresolved = [key for key in required_keys if not store.get("regions", {}).get(key, {}).get("region_id")]
        if unresolved:
            nodes = collect_nodes(client.get(REGIONS_URL, context="regions").json())

        for index, key in enumerate(required_keys, 1):
            spec = target_specs[key]
            prev = dict(store.get("regions", {}).get(key, {}))
            region_id = str(prev.get("region_id") or "")
            api_name = str(prev.get("api_region_name") or "")
            if not region_id:
                node = resolve_region(nodes or [], spec["names"], spec["oblast"])
                if node is None:
                    request_errors[key] = "api_region_not_found"
                    store.setdefault("regions", {})[key] = {
                        **prev,
                        "city_key": key,
                        "target": spec["display_target"],
                        "continuous": False,
                        "last_error": request_errors[key],
                        "last_attempt_at": iso(datetime.now(UTC)),
                    }
                    print(f"[{index}/{len(required_keys)}] {key}: API region not found", flush=True)
                    continue
                region_id = node["regionId"]
                api_name = node["regionName"]

            try:
                history = history_rows(client, region_id, api_name or spec["display_target"])
                product_history_events = history_events(
                    history,
                    city_key=key,
                    region_id=region_id,
                    api_region_name=api_name or spec["display_target"],
                )
                current_lviv_observations = (
                    lviv_phase1_observations_from_history(
                        history,
                        region_id=region_id,
                        api_region_name=api_name or spec["display_target"],
                    )
                    if key == "lviv"
                    else []
                )
                checked_at = datetime.now(UTC)
                oldest = min((r["start"] for r in history), default=None)
                latest = max((r["end"] for r in history), default=None)
                initial_match = match_static_event(history, static[key])

                if prev.get("continuous") and prev.get("last_checked_at"):
                    previous_check = parse_dt(prev.get("last_checked_at"))
                    poll_overlap = bool(oldest and previous_check and oldest <= previous_check)
                    continuous = poll_overlap
                    reason = "history_reaches_previous_poll" if continuous else "history_window_no_longer_reaches_previous_poll"
                else:
                    poll_overlap = None
                    continuous = bool(initial_match)
                    reason = "static_alertsinua_event_matches_api" if continuous else "no_verified_static_api_event_match"

                if continuous:
                    for event in product_history_events:
                        upsert_completed_air_event(events, event)

                store.setdefault("regions", {})[key] = {
                    "city_key": key,
                    "kind": spec["kind"],
                    "target": spec["display_target"],
                    "oblast": spec["oblast"],
                    "region_id": region_id,
                    "api_region_name": api_name or spec["display_target"],
                    "continuous": continuous,
                    "continuity_reason": reason,
                    "initial_static_match": initial_match or prev.get("initial_static_match"),
                    "poll_overlap_verified": poll_overlap,
                    "history_completed_air_count": len(history),
                    "oldest_history_start": iso(oldest),
                    "latest_history_end": iso(latest),
                    "last_checked_at": iso(checked_at),
                    "last_error": None,
                }
                if key == "lviv":
                    lviv_ukrainealarm_observations = current_lviv_observations
                    lviv_checkpoint_state = dict(store["regions"][key])
                    lviv_fetched_this_run = True
                fetched_keys.append(key)
                print(
                    f"[{index}/{len(required_keys)}] {key}: continuous={continuous} "
                    f"region={region_id} history={len(history)} "
                    f"static_match={bool(initial_match)} poll_overlap={poll_overlap}",
                    flush=True,
                )
            except (
                UkraineAlarmAuthenticationError,
                UkraineAlarmRateLimitExhausted,
                UkraineAlarmRetryBudgetExceeded,
            ):
                # A systemic auth/rate-limit failure must stop the entire update,
                # rather than spending the remaining window on doomed regions.
                raise
            except Exception as exc:
                message = f"{type(exc).__name__}: {exc}"
                request_errors[key] = message
                store.setdefault("regions", {})[key] = {
                    **prev,
                    "city_key": key,
                    "target": spec["display_target"],
                    "region_id": region_id,
                    "api_region_name": api_name or spec["display_target"],
                    "last_error": message,
                    "last_attempt_at": iso(datetime.now(UTC)),
                }
                print(f"[{index}/{len(required_keys)}] {key}: ERROR {message}", flush=True)

        if len(fetched_keys) == len(required_keys) and not request_errors:
            store["last_successful_fetch_at"] = iso(datetime.now(UTC))
        store["last_fetch_error"] = None if not request_errors else request_errors
    elif not store.get("events"):
        print(f"{TOKEN_ENV} is not configured and bridge store is empty; API continuation skipped")

    store["events"] = sorted(
        events, key=lambda e: (e.get("start") or "", e.get("city_key") or "")
    )
    store["event_count"] = len(store["events"])

    persist_lviv_shadow_if_enabled(
        lviv_fetched_this_run=lviv_fetched_this_run,
        vadimkin_observations=lviv_vadimkin_observations,
        ukrainealarm_observations=lviv_ukrainealarm_observations,
        checkpoint_state=lviv_checkpoint_state,
    )

    STORE_FILE.write_text(json.dumps(store, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    now_local = datetime.now(TZ)
    status: dict[str, dict] = {}

    for key, cfg in exactmod.CITY_CONFIG.items():
        region_status = store.get("regions", {}).get(key, {})
        continuous = bool(region_status.get("continuous"))
        api_alerts = api_store_alerts(store, key) if continuous else []
        combined = union_alerts(
            [*exact_base[key], *static[key], *api_alerts],
            "historical_plus_alertsinua_plus_ukrainealarm",
        )
        meta = dict(cities.get(key, {}).get("meta", {}))
        meta.update(
            {
                "city_completed_alerts": len(combined),
                "latest_city_record_start": max(a.start for a in combined).isoformat(),
                "latest_city_record_end": max(a.end for a in combined).isoformat(),
                "data_source_kind": "exact-city history + Alerts.in.ua seam + official UkraineAlarm API",
                "static_bridge_events": len(static[key]),
                "ukrainealarm_bridge_events": len(api_alerts),
                "ukrainealarm_bridge_continuous": continuous,
                "ukrainealarm_api_region_id": region_status.get("region_id"),
            }
        )
        multicity_shadow_payload.record_city_alerts(key, combined, producer="apply_ukrainealarm_bridge")
        out = build_outputs(combined, now_local, meta)
        exactmod.enrich_weekly(out, combined)
        first_day = datetime.fromisoformat(cfg["valid_from"]).astimezone(TZ).date()
        exactmod.trim_first_partial_periods(out, first_day)
        cities[key] = out
        status[key] = {
            "primary_region": cfg["hromada"],
            "primary_continuous": continuous,
            "static_bridge_events_applied": len(static[key]),
            "api_bridge_events_applied": len(api_alerts),
            "latest_record_end": max(a.end for a in combined).isoformat(),
            "continuity_reason": region_status.get("continuity_reason"),
            "last_checked_at": region_status.get("last_checked_at"),
            "last_error": region_status.get("last_error"),
        }

    for key, cfg in proxy_cfg.items():
        region_status = store.get("regions", {}).get(key, {})
        continuous = bool(region_status.get("continuous"))
        api_alerts = api_store_alerts(store, key) if continuous else []
        combined = union_alerts(
            [*proxy_base[key], *static[key], *api_alerts],
            "historical_proxy_plus_alertsinua_plus_ukrainealarm",
        )
        meta = dict(cities.get(key, {}).get("meta", {}))
        meta.update(
            {
                "proxy_completed_alert_episodes": len(combined),
                "latest_proxy_record_start": max(a.start for a in combined).isoformat(),
                "latest_proxy_record_end": max(a.end for a in combined).isoformat(),
                "data_source_kind": "raion proxy history + Alerts.in.ua seam + official UkraineAlarm API",
                "static_bridge_events": len(static[key]),
                "ukrainealarm_bridge_events": len(api_alerts),
                "ukrainealarm_bridge_continuous": continuous,
                "ukrainealarm_api_region_id": region_status.get("region_id"),
            }
        )
        multicity_shadow_payload.record_city_alerts(key, combined, producer="apply_ukrainealarm_bridge")
        out = build_outputs(combined, now_local, meta)
        base.enrich_weekly(out, combined)
        base.trim_to_complete_coverage(out, date.fromisoformat(cfg["coverage_start"]))
        cities[key] = out
        status[key] = {
            "primary_region": cfg["raion"],
            "primary_continuous": continuous,
            "static_bridge_events_applied": len(static[key]),
            "api_bridge_events_applied": len(api_alerts),
            "latest_record_end": max(a.end for a in combined).isoformat(),
            "continuity_reason": region_status.get("continuity_reason"),
            "last_checked_at": region_status.get("last_checked_at"),
            "last_error": region_status.get("last_error"),
        }

    data["cities"] = cities
    keys = [k for k in mm.get("production_city_keys", []) if k in cities]
    data["comparison"] = {
        "monthly": generic_comparison(cities, keys, "monthly"),
        "weekly": generic_comparison(cities, keys, "weekly"),
    }

    covered = sorted(k for k in required_keys if status.get(k, {}).get("primary_continuous"))
    summary = {
        "source_url": HISTORY_URL,
        "regions_url": REGIONS_URL,
        "token_present_this_run": bool(token),
        "request_guard_seconds": MIN_API_INTERVAL_SECONDS,
        "cross_source_match_tolerance_seconds": MATCH_TOLERANCE_SECONDS,
        "static_bridge": static_info,
        "event_store_file": "data/ukrainealarm_bridge.json",
        "event_count": len(store.get("events", [])),
        "last_attempt_at": store.get("last_attempt_at"),
        "last_successful_fetch_at": store.get("last_successful_fetch_at"),
        "last_fetch_error": store.get("last_fetch_error"),
        "required_rows": sorted(required_keys),
        "continuity_verified_rows": covered,
        "continuity_unverified_rows": sorted(set(required_keys) - set(covered)),
        "fully_continuous": len(covered) == len(required_keys),
        "rows": status,
    }
    mm["official_ukrainealarm_bridge"] = summary
    DATA_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(f"Verified multicity bridge continuity: {len(covered)}/{len(required_keys)} rows")
    if request_errors:
        print("API request errors:", json.dumps(request_errors, ensure_ascii=False))


if __name__ == "__main__":
    main()
