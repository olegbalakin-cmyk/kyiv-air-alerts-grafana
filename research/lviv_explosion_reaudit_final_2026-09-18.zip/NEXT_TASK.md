PROJECT: explosion_metric
CITY_COMPLETED: Lviv
STATUS: complete_reaudited

RESULT:
- coverage: 2025-09-01..2026-09-17
- denominator: 126
- strict: 12/126 = 9.52%
- sensitivity: 12/126 = 9.52%
- included dates: 2025-09-03, 2025-09-10, 2025-10-05, 2025-11-19, 2026-01-08, 2026-01-15, 2026-02-05, 2026-02-08, 2026-02-11, 2026-03-18, 2026-03-24, 2026-07-30
- Telegram direct auditory hits for included events: 10/12
- local/web gap-search additions: 2 (2026-02-05, 2026-02-08)
- sensitivity-only cases: 0
- review-not-counted: 2026-01-27
- production deploy: NOT performed

NEXT:
- city: Lutsk
- denominator: 135
- coverage_start: 2025-11-06
- use same frozen Poltava/Uzhhorod rules
- Telegram = candidate discovery only; finish with local/web gap search
- write verbose evidence to files, not chat
- stop after Lutsk
