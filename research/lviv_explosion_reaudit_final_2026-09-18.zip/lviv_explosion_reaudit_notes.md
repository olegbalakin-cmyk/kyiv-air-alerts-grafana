# Lviv explosion metric — final re-audit

Coverage: `2025-09-01..2026-09-17`. Frozen production denominator: **126 completed alert episodes** for the Lviv raion proxy.

## Result

- strict: **12/126 = 9.52%**
- sensitivity: **12/126 = 9.52%**
- included alert episodes: 2025-09-03, 2025-09-10, 2025-10-05, 2025-11-19, 2026-01-08, 2026-01-15, 2026-02-05, 2026-02-08, 2026-02-11, 2026-03-18, 2026-03-24, 2026-07-30
- sensitivity-only cases: 0
- review-not-counted cases: 1 (2026-01-27)
- production deploy: not performed

## Key audit decisions

1. Multiple city explosions inside one continuous alert episode count once. This matters especially on 2025-10-05 and 2026-03-24.
2. The late-night 2026-01-08 attack crossed midnight. The first exact-city auditory reports were before midnight, so the episode is assigned to 8 January; the 9 January 00:04 follow-up is the same alert episode.
3. Telegram candidate discovery found 10 of the 12 included episodes. Local/web gap-search added **2026-02-05** and **2026-02-08**; both have exact-city Lviv evidence and explicit alert chronology.
4. 2026-02-17 is excluded from both numerators: authoritative reporting says explosions in **Lviv district**, with a drone near Lviv, but does not confirm exact-city auditory evidence.
5. 2026-01-27 remains review-not-counted. Strong reporting confirms the strike/explosion in Brody; secondary mentions were insufficient to establish a separate exact-city Lviv auditory event.
6. Non-air city explosions on 2026-02-22, 2026-03-16, 2026-04-27 and 2026-08-23 are excluded. The 2025-08-21 air-attack case is exact-city but precedes the frozen coverage start.
7. 2025-12-06 and 2026-09-13 are retained as region/non-city exclusions. For 13 September, authoritative current reporting places the attack in Stryi.

## Method

Strict requires exact city + confirmed air-war context + exact time in an active alert or explicit during-alert evidence. Sensitivity may additionally include strong near-boundary or inferred-same-attack cases; none were needed here. The metric is a media reconstruction of public reports that explosions were heard in the city during an alert, not a registry of all physical explosions.
