-- C6-22CITY-READER-01. Use on existing READ-ONLY RECOVERY compute only.
-- No writes, no temporary tables, no branch changes, no live API calls.
-- psql runner should set :asof_utc explicitly to the verified site-prod
-- data.meta.generated_at; the time is NOT the execution clock.
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SELECT current_database(), current_setting('transaction_read_only') AS read_only,
       pg_is_in_recovery() AS recovery, txid_current_snapshot()::text AS snapshot,
       pg_last_wal_replay_lsn()::text AS replay_lsn, CURRENT_TIMESTAMP AS observed_at;
-- Fail closed if read_only <> 'on' or recovery <> true.
SELECT city_key, episode_uid, start_at, end_at, created_by_run_id, created_at
FROM public.alert_episodes
WHERE city_key IN (
  'kharkiv','zaporizhzhia','sevastopol','cherkasy','zhytomyr','dnipro',
  'khmelnytskyi','poltava','rivne','sumy','vinnytsia','kropyvnytskyi',
  'lviv','chernihiv','odesa','kherson','mykolaiv','lutsk','uzhhorod',
  'ivano_frankivsk','ternopil','chernivtsi')
  AND alert_type = 'AIR' AND episode_state = 'closed'
  AND start_at < :'asof_utc'::timestamptz
  AND end_at <= :'asof_utc'::timestamptz
  AND created_at <= :'asof_utc'::timestamptz
ORDER BY city_key, start_at, end_at, episode_uid;
ROLLBACK;
