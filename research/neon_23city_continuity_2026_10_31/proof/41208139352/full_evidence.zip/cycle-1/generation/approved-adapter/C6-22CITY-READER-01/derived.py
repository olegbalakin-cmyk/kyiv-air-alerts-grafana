"""Pure research-only derivation of site_derived.json consumer fields.

Uses pinned site-prod build_time_of_day_heatmap functions, NEVER its main().
Input data/alerts_combined.json is used *only* to retain Kyiv as pinned reference
for the 23-city exploration structure; Kyiv is not regenerated from Neon.
"""
from __future__ import annotations

import copy
from datetime import date, datetime, time, timedelta
from pathlib import Path

from contract import CITY_KEYS, COVERAGE, KYIV, PROXY, UTC, aware


def create_derived(candidate: dict, reference_derived: dict, alerts22: dict,
                   now: datetime, site_root: Path, mods: dict) -> dict:
    """Create site-compatible copy for all 22 city sections, keeping Kyiv read-only.

    Generates time-of-day, common table, explorations and current-day partial
    through production's existing pure Python functions.
    """
    heat = mods['build_time_of_day_heatmap']
    rolling = mods['apply_site_rolling_7d']
    source = mods['update_data']
    keys = candidate['multicity_meta']['production_city_keys']
    if len(keys) != 23 or set(keys) != {*CITY_KEYS, 'kyiv'}:
        raise ValueError('Unexpected 23-city consumer selector')
    kyiv_data = site_root / 'data' / 'alerts_combined.json'
    import json
    raw = json.loads(kyiv_data.read_text(encoding='utf-8'))
    # Read-only from a frozen site-prod file. No Kyiv query, projection or mutation.
    kyiv_alerts = [source.Alert(start=aware(r['start']).astimezone(KYIV),
                                end=aware(r['end']).astimezone(KYIV),
                                source=r.get('source','site_prod_frozen_kyiv'))
                   for r in raw]
    alerts = {'kyiv': kyiv_alerts, **alerts22}
    result = copy.deepcopy(reference_derived)
    dashboard = copy.deepcopy(candidate)
    coverage = {}
    ends = {}
    for key in keys:
        meta = candidate['cities'][key]['meta']
        coverage[key] = date.fromisoformat(str(meta.get('coverage_start') or meta.get('first_city_level_date'))[:10])
        ends[key] = date.fromisoformat(meta['analysis_end'])
    for key in CITY_KEYS:
        start, end = coverage[key], ends[key]
        heat_rows = {period: heat.period_heatmap(alerts[key], start, end, days)
                     for period, days in heat.PERIODS.items()}
        result['time_of_day_heatmap_test']['cities'][key] = {
            'coverage_start': start.isoformat(),
            'analysis_end': end.isoformat(),
            'source_type': candidate['multicity_meta']['cities'][key]['source_type'],
            'periods': heat_rows,
        }
        table_meta = reference_derived['all_cities_table_test']['meta']
        table_start = date.fromisoformat(table_meta['common_start'])
        table_end = date.fromisoformat(table_meta['common_end'])
        table_periods = {}
        for name,length in (('7d',7),('30d',30),('90d',90),('year',365),('common',None)):
            lower = table_start if length is None else max(table_start, table_end - timedelta(days=length-1))
            table_periods[name] = heat.period_summary(alerts[key], lower, table_end)
        result['all_cities_table_test']['cities'][key] = {'periods': table_periods}
    # Recompute exploration content. Keep Kyiv's exact published JSON subtree:
    # running publisher-latest Kyiv logic is out of scope.
    explorations = heat.build_exploration_payload(dashboard, keys, alerts, coverage, ends, now)
    if reference_derived.get('explorations', {}).get('cities', {}).get('kyiv'):
        explorations['cities']['kyiv'] = copy.deepcopy(reference_derived['explorations']['cities']['kyiv'])
    current_day = now.astimezone(KYIV).date().isoformat()
    daily28_current = {}
    for key in CITY_KEYS:
        city = copy.deepcopy(candidate['cities'][key])
        heat.enrich_daily28_active_durations(city, alerts[key])
        heat.append_current_day_daily28(city, alerts[key], now.astimezone(KYIV))
        last = city.get('daily28', [])[-1] if city.get('daily28') else None
        if last and last.get('date') == current_day and last.get('is_partial_period') is True:
            daily28_current[key] = last
    original_current = reference_derived.get('explorations',{}).get('daily28_current',{})
    if original_current.get('cities',{}).get('kyiv'):
        daily28_current['kyiv'] = copy.deepcopy(original_current['cities']['kyiv'])
    explorations['daily28_current'] = {
        'meta': {
            'timezone': 'Europe/Kyiv',
            'current_day': current_day,
            'current_day_is_partial': True,
            'kpi_period_unchanged': True,
            'city_count': len(daily28_current),
        },
        'cities': daily28_current,
    }
    result['explorations'] = explorations
    result.setdefault('meta',{})['source'] = 'research-only; not the production updater'
    return result


def diff_derived(reference: dict, candidate: dict) -> dict:
    items=[]
    for section in ('time_of_day_heatmap_test','all_cities_table_test','explorations'):
        for key in CITY_KEYS:
            old = reference.get(section, {}).get('cities',{}).get(key)
            new = candidate.get(section, {}).get('cities',{}).get(key)
            if old != new:
                items.append({'section':section,'city_key':key,
                              'known_dst_related':key in ('kharkiv','zhytomyr','poltava','cherkasy')})
    for key in CITY_KEYS:
        old = reference.get('explorations',{}).get('daily28_current',{}).get('cities',{}).get(key)
        new = candidate.get('explorations',{}).get('daily28_current',{}).get('cities',{}).get(key)
        if old != new:
            items.append({'section':'explorations.daily28_current','city_key':key,
                          'known_dst_related':key in ('kharkiv','zhytomyr','poltava','cherkasy')})
    return {'total_diff_sections':len(items),'differences':items,
            'verdict':'SHAPE_MATH_MATCH_ONLY' if not items else 'PARTIAL_DISCREPANCIES',
            'production_reader_switch':False}
