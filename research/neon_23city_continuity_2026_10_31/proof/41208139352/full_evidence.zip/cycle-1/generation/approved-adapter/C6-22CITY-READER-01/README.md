# C6-22CITY-READER-01 — Neon → site presentation (research-only)

**Вердикт цього виконання: `PARTIAL`. Production reader switch: `NO`.**

Пакет призначений для **22 міст без Києва** і не модифікує Neon, Git, production-сайт, Actions, джерела чи координаційні документи. Конкретний приклад JSON/CSV сформований локально з **22 фактично прочитаних на реальній Neon replica інтервалів (по одному на місто)**. Це навмисно **неповна вибірка** для перевірки формату, а не повні ряди, не 28-денна статистика і не production parity.

## 1. Підтверджене середовище

- Прочитано актуальні `main:PROJECT_STATE.md`, `main:CHANGELOG.md`.
- Верифіковані HEAD: `main@3022daa8aac71520f493733576ed283a57771d46`, `site-prod@09192a36dae49bd71e1042942481384a5e763086`, operational WIP `ce472edadc96152fd379699bb5ef09250946b0f5`.
- Підтверджено успішні фактичні GitHub Actions runs `41010190316`, `40954898510`, `40968666492`; поточний ZIP **не** містить повторно завантажених inner proof artifacts цих runs.
- Neon project `green-cake-44216048`, branch `br-bold-mode-b5rub8pq`, read-only compute `ep-calm-rice-b5073ypp`, database `neondb`; `transaction_read_only=on`, `pg_is_in_recovery()=true`. Проведено лише SELECT.
- У 22 містах — **28 951** фізичних завершених AIR-епізодів (as-of production QA timestamp), з них 560 Севастополь. Перевірено відсутність `end_at<=start_at`. Ці перевірки — окремі SQL statements, а не frozen transactional multi-export.
- `alert_episode_sources`: 21 місто не має жодного link. Львів: 126/163 епізодів із прив'язками, 143 source-link rows. Link ≠ publisher HTTP→actual physical UID proof.

## 2. Контракт сайт → JSON → CSV

`site-prod@09192a36`:

| Consumer / source | Контракт |
|---|---|
| `pages-preview/app.js` | Читає `data/dashboard_data.json` і `data/site_derived.json`. City selector використовує 23 production keys. |
| `data/dashboard_data.json` | `cities[city_key].meta/kpis/daily28/monthly/weekly/rolling30/rolling90`, `comparison`, `all_cities_table`, `time_of_day_profile`, `multicity_meta`; повний Git blob `a3a30b5...`, 16 272 136 B. |
| `data/site_derived.json` | `time_of_day_heatmap_test`, `all_cities_table_test`, `explorations` із `daily28_current`; Git blob `8753373...`, 9 125 848 B. |
| `scripts/update_data.py` | `build_outputs()` — 28 завершених днів; starts за локальною датою початку; тривалість за UTC з clipping на північ `Europe/Kyiv`; complete months. |
| `scripts/apply_site_rolling_7d.py` | `update_city_rolling()` — rolling 7/30/90 завершених днів, частковий поточний місяць. Слово `weekly` означає rolling 7 days, а не лише календарні Mon–Sun. |
| `scripts/build_time_of_day_heatmap.py` | Окремо формує partial **current day** і `site_derived`. Його `main()` **не можна** викликати в research adapter, бо воно завантажує зовнішні джерела. |
| CSV із UI | Кнопки в `pages-preview/app.js` **генерують файли в браузері** з поточного вибору серій; не існує по одному статичному CSV на всі 22 міста. |
| `data/short_28d.csv`, `monthly.csv`, `weekly.csv` | Поточні репозиторні статичні CSV — київські, не 22-міські site outputs. |

**Географія:** `kharkiv`, `zaporizhzhia` — exact-city; `sevastopol` — exact-city *лише* сигнали окупаційної адміністрації (без легітимації її статусу), окремі верифіковані повні ON/OFF пари; 19 інших — **raion proxy**, не сигнали в адміністративних межах міста. Дати coverage збережено відповідно до production generator. Київ не читається з Neon і не перегенеровується.

## 3. Код і спосіб виконання

- `contract.py`: UTC interval union, civil-day clipping, 22-city geography registry, демонстраційний обмежений exporter.
- `adapter.py`: створює production-подібні `cities[22]`, 28d / rolling7/30/90 / complete+partial months, `comparison`, `all_cities_table`, `time_of_day_profile` **шляхом викликів наявних pinned pure функцій** `build_outputs`, `enrich_weekly`, `trim_to_complete_coverage` / `trim_first_partial_periods`, `update_city_rolling`, `period_summary`, `time_profile`. Git HEAD та blob SHA-1 потрібних модулів звіряються перед виконанням.
- `derived.py`: відтворює структури `site_derived.json` через pure функції з `build_time_of_day_heatmap.py`, з окремою обробкою current partial day; Київ зберігається за pinned локальним Git-файлом, а не за Neon.
- `sql/read_only_22city.sql`: шаблон єдиної repeatable-read read-only транзакції із **as-of reference timestamp**, без DML/DDL.
- `verify_sample.py`, `tests/`: перевірки формату та DST; `proof/` — рецепти і обмеження.

**Для локальної перевірки обмеженого прикладу:**

```bash
cd C6-22CITY-READER-01
python -m unittest discover -s tests -p 'test_*.py' -v
python adapter.py --sample-only --rows-json examples/real_neon_sample_22.json --output-dir /tmp/c6-22city-sample
python verify_sample.py
```

**Для виконання повного читача та машинного diff на окремо авторизованому захищеному runner:**

```bash
# Для цього кроку потрібні: точний локальний checkout site-prod@09192a36,
# Python 3.12+, встановлені production requirements, psycopg[binary],
# і existing read-only replica connection string зі сховища секретів runner.
# Секрет ніколи не передавати як параметр CLI чи в artifact.
python adapter.py \
  --repo-root /path/to/PINNED/site-prod/kyiv-air-alerts-grafana \
  --output-dir /tmp/c6-22city-full
```

Механізм бере URL з environment `C6_B1_READONLY_DATABASE_URL` **тільки в пам'яті захищеного runner**. Відмовляє, якщо підключився не до recovery read-only replica, якщо відрізняється HEAD або перевірені file blobs, якщо output-dir усередині репозиторію, чи якщо міста / source types не відповідають контракту. Порівнює власні згенеровані JSON із pinned site-prod, створює `machine_diff.json`, `machine_derived_diff.json`, `machine_verdict.json`. Виявлені розбіжності не приховує. Жоден `PASS_MATH_SHAPE_ONLY` **не** дає права на cutover.

Адаптер в поточному виконанні **не мав** захищеного psycopg→Neon каналу, а весь `dashboard_data.json` (16 MB) / `site_derived.json` (9 MB) не був доступний для матеріалізації через конектор, хоча SHA цих файлів підтверджено. Тому цей ZIP не містить фізичного повного 22-city end-to-end diff та **не називає його PASS**.

## 4. Відомі blocking discrepancies

1. **DST 25.10.2026:** Харків, Житомир, Полтава, Черкаси. Попередній `C6-MULTICITY-PARITY-01` установив 7 первинних інтервалів проти трьох неправильно злитих записів Neon (загалом 10 interval-side diffs). Попередні первинні 7 рядків / raw proof у цей пакет повторно не імпортовано. Не можна виправити це просто злиттям уже зіпсованих Neon rows у reader. Перехід осіннього DST: UTC-сортування і UTC-віднімання обов'язкові.
2. **22-city source lineage:** 21 місто — 0 source links, Львів — лише частково. Навіть повна числова рівність не доводить первинний source→UID provenance.
3. **Поточний день:** production `site_derived.explorations.daily28_current` є частковим; completed-only Neon може не містити активний AIR на момент генерації. Порівняння має явно розрізняти factual as-of, ingestion delay та incomplete active alerts.
4. **Часткові тижні/місяці:** `weekly` — 7-day rolling, `monthly` включає partial current month, а 28d KPI виключає current day. Не замінювати це календарною агрегацією SQL.
5. **Відсутність повного payload для diff:** `proof/machine_diff.json` чесно містить `null` у поля production parity. Відновити повні bytes pinned `site-prod` і виконати real read-only Python→Neon на захищеному runner.
6. **Client-side CSV:** sample CSV — тільки форматний приклад, не реальний UI export усіх видимих серій. Повноту CSV слід перевіряти проти `pages-preview/app.js` та JSON після full diff, не проти статичних київських CSV.

## 5. Мінімальний шлях інтеграції (поки без дозволу на deployment)

На наявному етапі production pipeline після підготовки `multicity_canonical_shadow` і **до** оновлення `dashboard_data.json` можна мати окремий `read-only shadow` генератор із тих самих `build_outputs` і `update_city_rolling`. Він збирає лише 22 city slices, не переписує Київ / casualty / backfill, віддає JSON у тимчасовий ізольований каталог і робить same-as-of diff. Друга стадія відтворює `site_derived` через існуючі pure builders без HTTP. Лише якщо всі consumer поля / source географія / DST / fresh/partial і lineage буде прийнято окремим gate, можна **планувати**, але **не виконувати** production switch.

Важливо: `main:PROJECT_STATE.md`, `main:CHANGELOG.md` у цьому завданні **не змінено**, бо scope прямо забороняє координаційні edits. Авторитетні поточні checkpoints лишаються з `main`.

## 6. Proof inventory

- `proof/neon_actual_readback.json` — реальні SQL SELECT, actual physical city counts, read-only guard, source-link coverage, checked Actions, межі доказу.
- `proof/sample_validation.json` — 11/11 PASS лише limited example JSON/CSV.
- `proof/offline_tests.log` — 22/22 PASS (UTC/DST 23/25h, source identity, JSON/CSV shape, diff fail-closed).
- `proof/machine_diff.json` — повне production comparison **INPUT_BLOCKED**, без вигаданих збігів.
- `proof/machine_verdict.json` — `PARTIAL` і blocking discrepancies.
- `sha256_manifest.json` — hash усіх файлів пакета (крім самого manifest, ZIP).
