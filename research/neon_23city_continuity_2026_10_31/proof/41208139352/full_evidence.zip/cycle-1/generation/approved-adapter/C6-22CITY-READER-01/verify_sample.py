#!/usr/bin/env python3
"""Machine-check the limited real-Neon example. NOT a production parity check."""
import csv
import hashlib
import io
import json
from pathlib import Path
from contract import CITY_KEYS, EXACT, PROXY, DST_KNOWN, aware

root = Path(__file__).resolve().parent
source = root / 'examples/real_neon_sample_22.json'
output = root / 'examples/site_compatible_SAMPLE_INCOMPLETE.json'
csvpath = root / 'examples/city_daily28_SAMPLE_INCOMPLETE.csv'
raw = json.loads(source.read_text('utf-8'))
payload = json.loads(output.read_text('utf-8'))
with open(csvpath,encoding='utf-8-sig',newline='') as handle:
    rows = list(csv.DictReader(handle))
checks = {
    'sample_22_distinct_real_neon_city_keys': len(raw)==22 and {x['city_key'] for x in raw} == set(CITY_KEYS),
    'all_sample_timestamps_utc_aware_valid': all(aware(x['end_at'])>aware(x['start_at']) for x in raw),
    'site_shape_22_cities_no_kyiv': set(payload['cities'])==set(CITY_KEYS),
    'exact_three_proxy_nineteen': sum(payload['cities'][k]['meta']['source_type']=='exact_city' for k in CITY_KEYS)==3,
    'sevastopol_special_provenance': payload['cities']['sevastopol']['meta']['source_provenance']=='occupation_administration',
    'all_samples_flagged_INCOMPLETE': all(x['sample_incomplete'] is True for k in CITY_KEYS for x in payload['cities'][k]['daily28']),
    'no_fake_28d_kpis': all(not payload['cities'][k]['kpis'] for k in CITY_KEYS),
    'csv_utf8_bom': csvpath.read_bytes().startswith(b'\xef\xbb\xbf'),
    'csv_has_22_cities': {r['city_key'] for r in rows} == set(CITY_KEYS),
    'no_current_day_in_daily28': all(r['date']<'2026-10-30' for r in rows),
    'four_known_dst_open': set(DST_KNOWN)=={'kharkiv','zhytomyr','poltava','cherkasy'},
}
proof = {
    'status': 'PASS_LIMITED_EXAMPLE_SHAPE_ONLY' if all(checks.values()) else 'FAIL',
    'checks': checks, 'check_count': len(checks), 'pass_count': sum(checks.values()),
    'data_provenance': 'one real read-only Neon closed AIR interval per city',
    'scope': 'INCOMPLETE SAMPLE ONLY',
    'production_parity': 'NOT_TESTED',
    'sample_rows': len(raw), 'daily_csv_rows': len(rows),
    'raw_sample_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'output_sample_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'csv_sha256': hashlib.sha256(csvpath.read_bytes()).hexdigest(),
}
path = root/'proof'/'sample_validation.json'
path.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':proof['status'],'checks':len(checks),'passed':sum(checks.values()),'csv_rows':len(rows)}))
raise SystemExit(0 if all(checks.values()) else 1)
