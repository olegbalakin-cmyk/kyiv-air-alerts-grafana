"""Pinned C6 22-city read-only projection contract (site-prod@09192a36)."""
from __future__ import annotations

import csv
import io
import json
import math
from collections import defaultdict
from datetime import date, datetime, time, timedelta, timezone
from statistics import mean
from zoneinfo import ZoneInfo

UTC = timezone.utc
KYIV = ZoneInfo("Europe/Kyiv")
EXACT = ("kharkiv", "zaporizhzhia", "sevastopol")
PROXY = (
    "cherkasy", "zhytomyr", "dnipro", "khmelnytskyi", "poltava", "rivne",
    "sumy", "vinnytsia", "kropyvnytskyi", "lviv", "chernihiv", "odesa",
    "kherson", "mykolaiv", "lutsk", "uzhhorod", "ivano_frankivsk",
    "ternopil", "chernivtsi",
)
CITY_KEYS = EXACT + PROXY
DST_KNOWN = ("kharkiv", "zhytomyr", "poltava", "cherkasy")
EXPECTED_SITE_SHA = "09192a36dae49bd71e1042942481384a5e763086"
EXPECTED_DASHBOARD_BLOB = "a3a30b5b9772e55c2941a01303de88551f4298bb"
EXPECTED_DERIVED_BLOB = "875337323602b26951dd5472e1c3592cb0b76ab5"

# Validated start dates are dictated by the site-prod generator; NEVER infer geographic
# authority from the DB city_key alone.
COVERAGE = {
    "kharkiv": "2025-02-17", "zaporizhzhia": "2025-03-19",
    "sevastopol": "2023-09-25",
    "cherkasy": "2025-01-10", "zhytomyr": "2025-01-23",
    "dnipro": "2025-05-01", "khmelnytskyi": "2025-07-07",
    "poltava": "2025-08-01", "rivne": "2025-08-01",
    "sumy": "2025-08-06", "vinnytsia": "2025-08-21",
    "kropyvnytskyi": "2025-09-01", "lviv": "2025-09-01",
    "chernihiv": "2025-09-03", "odesa": "2025-11-04",
    "kherson": "2025-08-30", "mykolaiv": "2025-11-05",
    "lutsk": "2025-11-06", "uzhhorod": "2025-11-06",
    "ivano_frankivsk": "2025-11-06", "ternopil": "2025-11-06",
    "chernivtsi": "2025-11-06",
}
RAION = {
    "cherkasy": "Черкаський район", "zhytomyr": "Житомирський район",
    "dnipro": "Дніпровський район", "khmelnytskyi": "Хмельницький район",
    "poltava": "Полтавський район", "rivne": "Рівненський район",
    "sumy": "Сумський район", "vinnytsia": "Вінницький район",
    "kropyvnytskyi": "Кропивницький район", "lviv": "Львівський район",
    "chernihiv": "Чернігівський район", "odesa": "Одеський район",
    "kherson": "Херсонський район", "mykolaiv": "Миколаївський район",
    "lutsk": "Луцький район", "uzhhorod": "Ужгородський район",
    "ivano_frankivsk": "Івано-Франківський район",
    "ternopil": "Тернопільський район", "chernivtsi": "Чернівецький район",
}


def aware(raw: str | datetime) -> datetime:
    d = datetime.fromisoformat(raw.replace("Z", "+00:00")) if isinstance(raw, str) else raw
    if d.tzinfo is None or d.utcoffset() is None:
        raise ValueError("Timezone-aware timestamps required")
    return d.astimezone(UTC)


def midnight(day: date) -> datetime:
    return datetime.combine(day, time.min, tzinfo=KYIV).astimezone(UTC)


def days(first: date, last: date):
    day = first
    while day <= last:
        yield day
        day += timedelta(days=1)


def union_utc(intervals: list[tuple[datetime, datetime]]) -> list[tuple[datetime, datetime]]:
    spans = sorted([(aware(s), aware(e)) for s, e in intervals], key=lambda x: (x[0], x[1]))
    merged = []
    for start, end in spans:
        if end <= start:
            raise ValueError("Invalid closed AIR interval")
        if not merged or start > merged[-1][1]:
            merged.append([start, end])
        elif end > merged[-1][1]:
            merged[-1][1] = end
    return [(s, e) for s, e in merged]


def count_and_duration(intervals: list[tuple[datetime, datetime]], start: date, end: date):
    """Return per-day starts, active-segment count, UTC union seconds, mean episode mins.

    Starting-event counts are separate from active segments. A segment crossing local
    midnight contributes to both days' active time, but only its start day count.
    """
    starts = defaultdict(int)
    durations = defaultdict(list)
    segments = defaultdict(list)
    for s, e in intervals:
        s, e = aware(s), aware(e)
        if e <= s:
            raise ValueError("Reversed interval")
        day = s.astimezone(KYIV).date()
        if start <= day <= end:
            starts[day] += 1
            durations[day].append((e - s).total_seconds() / 60)
        a = max(s, midnight(start))
        b = min(e, midnight(end + timedelta(days=1)))
        if b <= a:
            continue
        for day in days(max(start, a.astimezone(KYIV).date()),
                        min(end, b.astimezone(KYIV).date())):
            seg_s = max(a, midnight(day))
            seg_e = min(b, midnight(day + timedelta(days=1)))
            if seg_e > seg_s:
                segments[day].append((seg_s, seg_e))
    res = {}
    for day in days(start, end):
        union = union_utc(segments[day]) if segments[day] else []
        sec = sum((b - a).total_seconds() for a, b in union)
        res[day] = {
            "alerts_started": starts[day],
            "active_alerts": len(union),
            "seconds": sec,
            "avg_alert_duration_min": round(mean(durations[day]), 3) if durations[day] else None,
            "avg_active_alert_duration_min": round(sec / (60 * len(union)), 3) if union else None,
        }
    return res


def sample_site_compatible(rows: list[dict], now: datetime) -> dict:
    """An *illustrative subset*, not a production-parity result.

    Offline execution on 22 actual sampled Neon intervals; missing days and
    historical time series must be marked unavailable, NEVER filled with zero.
    """
    today = aware(now).astimezone(KYIV).date()
    end = today - timedelta(days=1)
    start = end - timedelta(days=27)
    grouped = defaultdict(list)
    for row in rows:
        city = row["city_key"]
        if city not in CITY_KEYS:
            raise ValueError(f"Out-of-scope city: {city}")
        grouped[city].append((aware(row["start_at"]), aware(row["end_at"])))
    if set(grouped) != set(CITY_KEYS):
        raise ValueError("Expected exactly 22 different city keys")
    cities = {}
    for key in CITY_KEYS:
        iv = grouped[key]
        daily = count_and_duration(iv, start, end)
        daily_rows = []
        for d, record in daily.items():
            # Unobserved periods are NULL in an INCOMPLETE sample, never false 0.
            has_start = record["alerts_started"] > 0
            if not has_start and record["active_alerts"] == 0:
                continue
            daily_rows.append({
                "time": midnight(d).astimezone(KYIV).isoformat(),
                "date": d.isoformat(),
                "alerts_started": record["alerts_started"],
                "active_alerts": record["active_alerts"],
                "total_alert_duration_minutes": round(record["seconds"] / 60, 3),
                "total_alert_duration_hours": round(record["seconds"] / 3600, 3),
                "avg_alert_duration_minutes": record["avg_alert_duration_min"],
                "avg_active_alert_duration_minutes": record["avg_active_alert_duration_min"],
                "sample_incomplete": True,
            })
        cities[key] = {
            "meta": {"source_type": "exact_city" if key in EXACT else "raion_proxy",
                     "coverage_start": COVERAGE[key], "proxy_raion": RAION.get(key),
                     "sample_only": True, "analysis_end": end.isoformat(),
                     "timezone": "Europe/Kyiv",
                     "source_provenance": "occupation_administration" if key == "sevastopol" else "NOT_PROVEN_PER_EPISODE"},
            "daily28": daily_rows,
            "weekly": [], "rolling30": [], "rolling90": [], "monthly": [], "kpis": [],
        }
    return {"meta": {"research_only": True, "INCOMPLETE_SAMPLE_DO_NOT_DEPLOY": True,
                     "baseline_site_prod_sha": EXPECTED_SITE_SHA,
                     "generated_at_for_demo": aware(now).isoformat(),
                     "timezone": "Europe/Kyiv"}, "cities": cities}


def csv_export_daily28(sample: dict) -> str:
    fields = ["city_key", "date", "time", "alerts_started", "active_alerts",
              "total_alert_duration_minutes", "total_alert_duration_hours",
              "avg_alert_duration_minutes", "avg_active_alert_duration_minutes", "sample_incomplete"]
    out = io.StringIO(newline="")
    writer = csv.DictWriter(out, fieldnames=fields, lineterminator="\r\n")
    writer.writeheader()
    for city in CITY_KEYS:
        for row in sample["cities"][city]["daily28"]:
            writer.writerow({"city_key": city, **row})
    return "\ufeff" + out.getvalue()
