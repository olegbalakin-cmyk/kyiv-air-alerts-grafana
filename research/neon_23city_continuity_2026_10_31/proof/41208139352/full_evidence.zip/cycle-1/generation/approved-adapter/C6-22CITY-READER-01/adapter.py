#!/usr/bin/env python3
"""C6-22CITY-READER-01: research-only 22-city physical Neon -> site structures.

NEVER edits a Git checkout or a database. Production use prohibited.
The full mode requires a pinned local site-prod checkout and psycopg, whereas
--sample-only can run against the small supplied genuine Neon observations.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import json
import os
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from contract import (
    CITY_KEYS, COVERAGE, DST_KNOWN, EXACT, EXPECTED_DASHBOARD_BLOB,
    EXPECTED_DERIVED_BLOB, EXPECTED_SITE_SHA, KYIV, PROXY, RAION, UTC,
    aware, csv_export_daily28, sample_site_compatible, union_utc,
)

# Never call producer.main(): it would fetch external endpoints/publish files.
# Only reuse pure transformation routines from the exact pinned site generator.
PINNED_SOURCE_BLOBS = {
    "scripts/update_data.py": "cebc2b455fb08ee16e03b9e4fcdb17aa2d9d6833",
    "scripts/expand_multicity_production.py": "61c2d3cea37469de800fa242625a0d6db4884b1e",
    "scripts/add_duration_unit_switch.py": "354650af9bc73e0cfe76c2e9ab9a2e037d938042",
    "scripts/apply_ukrainealarm_bridge.py": "8b95c4b508b9a473240889603f593e399cf8815d",
    "scripts/apply_site_rolling_7d.py": "77ec779c657180ce0beb9608688f5561d871729c",
    "scripts/build_time_of_day_heatmap.py": "382e815dc95ec4e0d7cb3cb3619e3242aba823ce",
    "scripts/build_preview_historical_daily.py": "78d70f56b17da73c8bd1899360390f8f9dbad9df",
    "scripts/extend_remaining_proxies.py": "722a020cdf90db3374039015d3d77e53bc320b00",
    "scripts/add_sevastopol_exact.py": "e4c091a677622eb28e504b0592a89e4d92d5fe02",
    "data/alerts_combined.json": "7a7f066374cd3b35a86d7c113a430b12439e402b",
}

SITE_MODULES = (
    "update_data", "expand_multicity_production", "add_duration_unit_switch",
    "apply_ukrainealarm_bridge", "apply_site_rolling_7d",
    "build_time_of_day_heatmap", "build_preview_historical_daily",
)

READ_SQL = """\
SELECT city_key, episode_uid::text AS episode_uid, start_at, end_at,
       created_by_run_id::text AS created_by_run_id, created_at
FROM public.alert_episodes
WHERE city_key = ANY(%s)
  AND alert_type = 'AIR' AND episode_state = 'closed'
  AND start_at < %s AND end_at <= %s AND created_at <= %s
ORDER BY city_key, start_at, end_at, episode_uid;
"""


def git_blob_sha(path: Path) -> str:
    data = path.read_bytes()
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def git_revision(site_root: Path) -> str:
    done = subprocess.run(
        ["git", "-C", str(site_root), "rev-parse", "HEAD"],
        check=True, capture_output=True, text=True, timeout=15,
    )
    return done.stdout.strip()


def verify_reference(site_root: Path) -> dict:
    if not site_root.is_dir():
        raise ValueError("Missing local site-prod repository checkout")
    sha = git_revision(site_root)
    if sha != EXPECTED_SITE_SHA:
        raise ValueError(f"REF_SHA_MISMATCH: expected {EXPECTED_SITE_SHA}, got {sha}")
    files = {
        "dashboard_data": ("dashboard_data.json", EXPECTED_DASHBOARD_BLOB),
        "site_derived": ("site_derived.json", EXPECTED_DERIVED_BLOB),
    }
    result = {"site_prod_commit": sha, "verified_blob": {}}
    for key, (filename, wanted) in files.items():
        path = site_root / "data" / filename
        got = git_blob_sha(path)
        if got != wanted:
            raise ValueError(f"BLOB_MISMATCH {filename}: {got}, expected {wanted}")
        result["verified_blob"][key] = got
    for rel, expected in PINNED_SOURCE_BLOBS.items():
        got = git_blob_sha(site_root / rel)
        if got != expected:
            raise ValueError(f"PINNED_CODE_OR_SOURCE_BLOB_MISMATCH {rel}: {got}")
        result["verified_blob"][rel] = got
    return result


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def read_physical_neon(dsn: str, asof: datetime) -> tuple[list[dict], dict]:
    """One read-only repeatable-read PostgreSQL transaction; never any DML/DDL.

    Reject a primary or writable endpoint. `connect` is the only network call.
    Credentials stay in the invoking process and are never logged/artifacted.
    """
    try:
        import psycopg
        from psycopg.rows import dict_row
    except ImportError as exc:
        raise RuntimeError("psycopg is needed on the protected read-only runner") from exc
    if not dsn:
        raise ValueError("Empty DB URL")
    rows: list[dict] = []
    receipt = {}
    with psycopg.connect(dsn, row_factory=dict_row, connect_timeout=20,
                         autocommit=True, options="-c default_transaction_read_only=on") as conn:
        with conn.cursor() as cur:
            cur.execute("BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
            cur.execute("""SELECT current_database() AS db,
                current_setting('transaction_read_only') AS read_only,
                pg_is_in_recovery() AS recovery,
                txid_current_snapshot()::text AS snapshot,
                pg_last_wal_replay_lsn()::text AS replay_lsn,
                CURRENT_TIMESTAMP AS observed_at""")
            receipt = dict(cur.fetchone())
            if receipt["read_only"] != "on" or receipt["recovery"] is not True:
                raise RuntimeError("FAIL_CLOSED: endpoint is not read-only recovery replica")
            cur.execute(READ_SQL, (list(CITY_KEYS), asof, asof, asof))
            for raw in cur:
                rows.append({
                    "city_key": raw["city_key"],
                    "start_at": aware(raw["start_at"]).isoformat(),
                    "end_at": aware(raw["end_at"]).isoformat(),
                    "episode_uid": raw["episode_uid"],
                    "created_by_run_id": raw["created_by_run_id"],
                    "created_at": aware(raw["created_at"]).isoformat(),
                })
            cur.execute("ROLLBACK")  # explicitly end a read-only transaction
    if {row["city_key"] for row in rows} != set(CITY_KEYS):
        raise RuntimeError("FAIL_CLOSED: one or more of the 22 cities is missing from the as-of replica")
    return rows, {**receipt, "row_count": len(rows),
                  "cities": len({r["city_key"] for r in rows}),
                  "asof_utc": asof.isoformat(), "db_access": "READ_ONLY_RECOVERY"}


def import_site_modules(site_root: Path) -> dict:
    scriptdir = site_root / "scripts"
    if not scriptdir.is_dir():
        raise ValueError("Missing scripts/ in site-prod checkout")
    sys.path.insert(0, str(scriptdir))
    return {name: importlib.import_module(name) for name in SITE_MODULES}


def merged_input_by_city(rows: list[dict]) -> tuple[dict, dict]:
    groups = defaultdict(list)
    for row in rows:
        key = row["city_key"]
        if key not in CITY_KEYS:
            raise ValueError("Out-of-scope city: " + key)
        groups[key].append((aware(row["start_at"]), aware(row["end_at"])))
    if set(groups) != set(CITY_KEYS):
        raise ValueError(f"Expected 22 cities; observed {sorted(groups)}")
    merged = {key: union_utc(groups[key]) for key in CITY_KEYS}
    diag = {key: {
        "raw_physical_rows": len(groups[key]),
        "UTC_union_rows": len(merged[key]),
        "merges": len(groups[key]) - len(merged[key]),
        "DST_KNOWN_PROBLEM": key in DST_KNOWN,
    } for key in CITY_KEYS}
    return merged, diag


def _safe_meta(reference_city: dict, reference_mm: dict, key: str) -> dict:
    meta = copy.deepcopy(reference_city["meta"])
    mm = reference_mm["cities"][key]
    type_from_ref = mm["source_type"]
    expected = "exact_city" if key in EXACT else "raion_proxy"
    if type_from_ref != expected:
        raise ValueError(f"SOURCE_TYPE_CONTRACT_MISMATCH {key}: {type_from_ref} != {expected}")
    if key in PROXY and not mm.get("proxy_raion"):
        raise ValueError(f"MISSING_RAION_PROXY_METADATA {key}")
    if key == "sevastopol" and mm.get("source_provenance") != "occupation_administration":
        raise ValueError("SEVASTOPOL_SPECIAL_SOURCE_CONTRACT_MISMATCH")
    meta["source_type"] = expected
    meta["coverage_start"] = mm.get("coverage_start") or COVERAGE[key]
    if key in PROXY:
        meta["proxy_raion"] = mm["proxy_raion"]
    if key == "sevastopol":
        meta["source_provenance"] = "occupation_administration"
    return meta


def build_projection_from_site(rows: list[dict], reference: dict,
                               now: datetime, site_root: Path) -> tuple[dict, dict, dict]:
    """Call only existing pinned pure functions, never producer main().

    Produces the 22 city JSON subtrees, comparison, table and profile. Other
    23-city/attack/casualty/Kyiv projections are explicitly OUT OF SCOPE.
    """
    mm = reference.get("multicity_meta", {})
    keys = mm.get("production_city_keys", [])
    if len(keys) != 23 or set(keys) != {*CITY_KEYS, "kyiv"}:
        raise ValueError("Site 23-city selector contract differs from expected key set")
    mods = import_site_modules(site_root)
    source = mods["update_data"]
    rolling = mods["apply_site_rolling_7d"]
    multi = mods["expand_multicity_production"]
    exactmod = mods["add_duration_unit_switch"]
    bridge = mods["apply_ukrainealarm_bridge"]
    merged, diagnostics = merged_input_by_city(rows)
    output = copy.deepcopy(reference)
    alerts_by_city = {}
    for key in CITY_KEYS:
        if not reference.get("cities", {}).get(key):
            raise ValueError(f"Missing reference city {key}")
        alert_list = [source.Alert(start=s.astimezone(KYIV), end=e.astimezone(KYIV),
                                   source="neon_canonical_utc_union") for s, e in merged[key]]
        alerts_by_city[key] = alert_list
        meta = _safe_meta(reference["cities"][key], mm, key)
        fresh = source.build_outputs(alert_list, now.astimezone(KYIV), meta)
        if key in EXACT and key != "sevastopol":
            exactmod.enrich_weekly(fresh, alert_list)
            valid_day = date.fromisoformat(COVERAGE[key])
            exactmod.trim_first_partial_periods(fresh, valid_day)
        else:
            multi.enrich_weekly(fresh, alert_list)
            multi.trim_to_complete_coverage(fresh, date.fromisoformat(COVERAGE[key]))
            if key == "sevastopol":
                fresh["weekly"] = [r for r in fresh["weekly"] if r["week_start"] >= "2023-10-02"]
                fresh["monthly"] = [r for r in fresh["monthly"] if r["month"] >= "2023-10"]
                fresh["meta"]["first_complete_week_start"] = "2023-10-02"
                fresh["meta"]["first_complete_month"] = "2023-10"
        rolling.update_city_rolling(fresh, alert_list)
        # Do not launder unchanged unrelated site fields as Neon-generated.
        output["cities"][key] = fresh
    output["comparison"] = {
        "monthly": bridge.generic_comparison(output["cities"], keys, "monthly"),
        "weekly": bridge.generic_comparison(output["cities"], keys, "weekly"),
    }
    # Recalculate the 22 city-specific period summary and 15m profile, retaining
    # the untouched Kyiv reference slice for unchanged cross-city contracts.
    common_start = date.fromisoformat(reference["all_cities_table"]["meta"]["common_start"])
    common_end = date.fromisoformat(reference["all_cities_table"]["meta"]["common_end"])
    output.setdefault("all_cities_table", {}).setdefault("cities", {})
    output.setdefault("time_of_day_profile", {}).setdefault("cities", {})
    for key in CITY_KEYS:
        first = date.fromisoformat(COVERAGE[key])
        end = date.fromisoformat(output["cities"][key]["meta"]["analysis_end"])
        table = {}
        for label, length in (("7d",7),("30d",30),("90d",90),("year",365),("common",None)):
            window_start = common_start if length is None else max(common_start, common_end - timedelta(days=length - 1))
            table[label] = rolling.period_summary(alerts_by_city[key], window_start, common_end)
        output["all_cities_table"]["cities"][key] = {"periods": table}
        profiles = {}
        for label, length in (("7d",7),("30d",30),("90d",90),("year",365),("all",None)):
            profiles[label] = rolling.time_profile(alerts_by_city[key], first, end, length)
        output["time_of_day_profile"]["cities"][key] = {
            "coverage_start": first.isoformat(), "analysis_end": end.isoformat(),
            "source_type": "exact_city" if key in EXACT else "raion_proxy",
            "periods": profiles,
        }
    # Meta generated_at normally differs by seconds. Read-only and no spoofing:
    # the output preserves reference meta as provenance but is a shadow only.
    return output, diagnostics, alerts_by_city


def diff_rows(reference: dict, candidate: dict, *, max_details: int = 300) -> dict:
    """Deterministic machine diff of generated consumer keys, no silent tolerances."""
    fields = ("daily28", "weekly", "monthly", "rolling30", "rolling90", "kpis")
    report = {"site_prod_sha": EXPECTED_SITE_SHA, "cities": {},
              "per_city_discrepancies": {}, "blocking_details": [], "total_diff_items": 0,
              "known_dst_blocking_cities": list(DST_KNOWN),
              "reference_kind": "actual_pinned_Git_site_prod_if_supplied"}

    def record(key, path, want, got):
        report["total_diff_items"] += 1
        report["per_city_discrepancies"][key] = report["per_city_discrepancies"].get(key, 0) + 1
        if len(report["blocking_details"]) < max_details:
            report["blocking_details"].append({
                "city_key": key, "path": path, "site_prod": want, "neon_projection": got,
                "known_dst_related": key in DST_KNOWN,
            })

    for key in CITY_KEYS:
        old = reference["cities"][key]
        new = candidate["cities"][key]
        for field in fields:
            before = old.get(field)
            after = new.get(field)
            if not isinstance(before, list) or not isinstance(after, list):
                record(key, field, f"type:{type(before).__name__}", f"type:{type(after).__name__}")
                continue
            def row_id(row, n):
                return str(row.get("date") or row.get("week_end") or row.get("window_end") or row.get("month") or row.get("period_end") or n)
            a = {row_id(r,i): r for i,r in enumerate(before)}
            b = {row_id(r,i): r for i,r in enumerate(after)}
            for idx in sorted(set(a) | set(b)):
                if idx not in a or idx not in b:
                    record(key, f"{field}/{idx}", a.get(idx), b.get(idx))
                    continue
                for prop in sorted(set(a[idx]) | set(b[idx])):
                    av = a[idx].get(prop)
                    bv = b[idx].get(prop)
                    if av != bv:
                        record(key, f"{field}/{idx}/{prop}", av, bv)
        for prop in ("timezone", "analysis_end", "source_type", "coverage_start",
                     "proxy_raion", "weekly_mode", "first_complete_month"):
            a = old.get("meta", {}).get(prop)
            b = new.get("meta", {}).get(prop)
            if a != b:
                record(key, f"meta/{prop}", a, b)
        report["cities"][key] = {"rows": {p: len(new.get(p, [])) for p in fields},
                                  "discrepancies": report["per_city_discrepancies"].get(key, 0),
                                  "DST_KNOWN": key in DST_KNOWN}
    # Cross-city comparison and rolling/tables/profile must not be silently ignored.
    for field in ("monthly", "weekly"):
        ra = {x.get("time"):x for x in reference.get("comparison",{}).get(field,[])}
        rb = {x.get("time"):x for x in candidate.get("comparison",{}).get(field,[])}
        for t in sorted(set(ra)|set(rb)):
            for key in CITY_KEYS:
                for attr in ("alerts_per_day", "avg_daily_alert_hours", "avg_alert_duration_min"):
                    item=f"{key}_{attr}"; left=ra.get(t,{}).get(item); right=rb.get(t,{}).get(item)
                    if left != right:
                        record(key, f"comparison/{field}/{t}/{item}", left, right)
    for key in CITY_KEYS:
        for fld in ("time_of_day_profile", "all_cities_table"):
            a=reference.get(fld,{}).get("cities",{}).get(key)
            b=candidate.get(fld,{}).get("cities",{}).get(key)
            if a != b:
                record(key, f"{fld}/cities/{key}",
                       "REFERENCE_SUBTREE_DIFFERENT", "NEON_PROJECTED_SUBTREE_DIFFERENT")
    report["blocking_details_truncated"] = report["total_diff_items"] > len(report["blocking_details"])
    report["verdict"] = "PASS_MATH_SHAPE_ONLY" if report["total_diff_items"]==0 else "PARTIAL_BLOCKING_DIFFERENCES"
    # Even zero functional diff cannot establish source→UID provenance or cutover.
    report["production_cutover_allowed"] = False
    return report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo-root", type=Path, help="Pinned site-prod kyiv-air-alerts-grafana/ root")
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--dsn-env", default="C6_B1_READONLY_DATABASE_URL")
    ap.add_argument("--rows-json", type=Path, help="Offline physical readback fixture from a *verified* as-of snapshot")
    ap.add_argument("--sample-only", action="store_true", help="Honest 22-row real Neon sample, incomplete")
    args = ap.parse_args()
    # Never accidentally write inside a production checkout, not even a temp dir.
    if args.repo_root and args.output_dir.resolve().is_relative_to(args.repo_root.resolve()):
        ap.error("--output-dir must be OUTSIDE the site-prod repository")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.sample_only:
        if not args.rows_json:
            ap.error("--sample-only needs --rows-json")
        rows = load_json(args.rows_json)
        result = sample_site_compatible(rows, datetime.fromisoformat("2026-10-30T06:11:07+00:00"))
        write_json(args.output_dir / "site_compatible_SAMPLE_INCOMPLETE.json", result)
        (args.output_dir / "city_daily28_SAMPLE_INCOMPLETE.csv").write_text(
            csv_export_daily28(result), encoding="utf-8")
        print("PARTIAL: incomplete actual Neon sample, NEVER use as site parity proof")
        return 0
    if not args.repo_root:
        ap.error("--repo-root is mandatory for a full consumer comparison")
    receipt = verify_reference(args.repo_root)
    original = load_json(args.repo_root / "data" / "dashboard_data.json")
    asof = aware(original["meta"]["generated_at"])
    if args.rows_json:
        rows = load_json(args.rows_json)
        receipt["physical_origin"] = "user_supplied_file_UNVERIFIED_IN_THIS_RUN"
    else:
        rows, db = read_physical_neon(os.environ.get(args.dsn_env, ""), asof)
        receipt["database"] = db
        receipt["physical_origin"] = "ACTUAL_NEON_PSYCOG_READONLY"
    output, diagnostics, alerts22 = build_projection_from_site(rows, original, asof, args.repo_root)
    write_json(args.output_dir / "22city_neon_projection.json", output)
    write_json(args.output_dir / "UTC_union_diagnostics.json", diagnostics)
    diff = diff_rows(original, output)
    write_json(args.output_dir / "machine_diff.json", diff)
    # Second consumer artifact: a *full* 22-city site_derived projection.
    # Requires exactly the pinned site modules and a frozen Kyiv source slice.
    try:
        from derived import create_derived, diff_derived
        modules = import_site_modules(args.repo_root)
        original_derived = load_json(args.repo_root / "data" / "site_derived.json")
        projected_derived = create_derived(output, original_derived, alerts22,
                                           asof, args.repo_root, modules)
        write_json(args.output_dir / "site_derived_22city_projection.json", projected_derived)
        d_diff = diff_derived(original_derived, projected_derived)
    except Exception as exc:
        # Never count a failed derived regeneration as PASS.
        d_diff = {"verdict": "INPUT_BLOCKED", "error_type": type(exc).__name__,
                  "error": str(exc)[:250]}
    write_json(args.output_dir / "machine_derived_diff.json", d_diff)
    # Fail closed: 22-city source obs absent in Neon, known DST and full derived
    # consumer parity unverified, even when selected numeric rows happen to match.
    write_json(args.output_dir / "machine_verdict.json", {
        "verdict": "PARTIAL" if rows else "BLOCKED",
        "metrics_diff": diff["verdict"],
        "blocking_differences": diff["total_diff_items"],
        "known_dst_cities": list(DST_KNOWN),
        "source_to_physical_uid_provenance": "NOT_PROVEN",
        "derived_explorations_full_comparison": d_diff["verdict"],
        "neon_authority": False, "production_reader_switch": False,
        "receipt": receipt,
    })
    return 2 if diff["total_diff_items"] or d_diff["verdict"] not in ("SHAPE_MATH_MATCH_ONLY",) else 0


if __name__ == "__main__":
    raise SystemExit(main())
