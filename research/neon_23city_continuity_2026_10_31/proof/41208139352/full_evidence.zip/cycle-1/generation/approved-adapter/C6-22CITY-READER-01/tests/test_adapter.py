from __future__ import annotations

import copy
import json
import pathlib
import sys
import unittest
from datetime import date, datetime, timedelta, timezone

BASE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))

from contract import (CITY_KEYS, COVERAGE, DST_KNOWN, EXACT, PROXY, RAION,
                      KYIV, aware, midnight, union_utc, count_and_duration,
                      csv_export_daily28, sample_site_compatible)
from adapter import (READ_SQL, diff_rows, merged_input_by_city, _safe_meta)

UTC = timezone.utc


class ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = json.loads((BASE / "examples" / "real_neon_sample_22.json").read_text())

    def test_scoped_exactly_22_cities_no_kyiv(self):
        self.assertEqual(len(CITY_KEYS), 22)
        self.assertEqual(len(set(CITY_KEYS)),22)
        self.assertNotIn("kyiv", CITY_KEYS)
        self.assertEqual(set(CITY_KEYS), {r['city_key'] for r in self.rows})

    def test_exact_three_proxy_nineteen(self):
        self.assertEqual(len(EXACT), 3)
        self.assertEqual(len(PROXY), 19)
        self.assertEqual(set(RAION), set(PROXY))

    def test_known_dst_four_no_suppression(self):
        self.assertEqual(set(DST_KNOWN), {'kharkiv','zhytomyr','poltava','cherkasy'})

    def test_sevastopol_is_exact_special_occupation_admin(self):
        refcity = {'meta':{'timezone':'Europe/Kyiv'}}
        meta = _safe_meta(refcity, {'cities':{'sevastopol':{
            'source_type':'exact_city',
            'coverage_start':'2023-09-25',
            'source_provenance':'occupation_administration',
        }}}, 'sevastopol')
        self.assertEqual(meta['source_provenance'], 'occupation_administration')
        self.assertEqual(meta['source_type'], 'exact_city')

    def test_sevastopol_rejects_forged_source(self):
        with self.assertRaisesRegex(ValueError,'SEVASTOPOL'):
            _safe_meta({'meta':{}},{'cities':{'sevastopol':{
                'source_type':'exact_city',
                'source_provenance':'ukrainealarm',
            }}},'sevastopol')

    def test_proxy_rejects_missing_raion(self):
        with self.assertRaisesRegex(ValueError, 'RAION'):
            _safe_meta({'meta':{}}, {'cities':{'sumy':{'source_type':'raion_proxy'}}}, 'sumy')

    def test_dst_utc_real_repeated_hour_has_25h_day(self):
        self.assertEqual(midnight(date(2026,10,26))-midnight(date(2026,10,25)), timedelta(hours=25))

    def test_dst_spring_23h_day(self):
        self.assertEqual(midnight(date(2026,3,30))-midnight(date(2026,3,29)), timedelta(hours=23))

    def test_dst_fold_local_clock_reversal_must_not_merge(self):
        one = (aware('2026-10-25T00:10:00Z'), aware('2026-10-25T00:40:00Z'))
        two = (aware('2026-10-25T01:10:00Z'), aware('2026-10-25T01:40:00Z'))
        self.assertGreater(one[0].astimezone(KYIV).hour, 0)
        self.assertEqual(one[0].astimezone(KYIV).hour,two[0].astimezone(KYIV).hour)
        self.assertEqual(len(union_utc([two,one])),2)
        d=count_and_duration([one,two],date(2026,10,25),date(2026,10,25))
        self.assertEqual(d[date(2026,10,25)]['active_alerts'],2)
        self.assertEqual(d[date(2026,10,25)]['seconds'],3600)

    def test_fall_back_same_local_clock_duration_uses_utc(self):
        iv=[(aware('2026-10-25T00:20:00Z'), aware('2026-10-25T01:20:00Z'))]
        self.assertEqual(iv[0][0].astimezone(KYIV).hour,iv[0][1].astimezone(KYIV).hour)
        d=count_and_duration(iv,date(2026,10,25),date(2026,10,25))
        self.assertEqual(d[date(2026,10,25)]['seconds'],3600)

    def test_midnight_clipping_and_start_once(self):
        iv=[(aware('2026-10-24T20:30:00Z'),aware('2026-10-24T21:15:00Z'))]
        # UTC+3 until Oct 25 01:00Z; interval spans local midnight.
        d=count_and_duration(iv,date(2026,10,24),date(2026,10,25))
        self.assertEqual(d[date(2026,10,24)]['alerts_started'],1)
        self.assertEqual(d[date(2026,10,25)]['alerts_started'],0)
        self.assertEqual(d[date(2026,10,24)]['seconds'],1800)
        self.assertEqual(d[date(2026,10,25)]['seconds'],900)

    def test_overlap_union_no_double_count(self):
        iv=[(aware('2026-10-25T02:00:00Z'),aware('2026-10-25T03:00:00Z')),
            (aware('2026-10-25T02:30:00Z'),aware('2026-10-25T03:30:00Z'))]
        merged=union_utc(iv)
        self.assertEqual(len(merged),1)
        d=count_and_duration(merged,date(2026,10,25),date(2026,10,25))
        self.assertEqual(d[date(2026,10,25)]['seconds'],5400)
        self.assertEqual(d[date(2026,10,25)]['alerts_started'],1)

    def test_reversed_closed_intervals_rejected(self):
        with self.assertRaises(ValueError):
            union_utc([(aware('2026-10-25T03:00Z'),aware('2026-10-25T02:00Z'))])

    def test_no_naive_timestamps(self):
        with self.assertRaisesRegex(ValueError,'aware'):
            aware('2026-10-25T03:40:00')

    def test_no_kiev_or_unknown_city_in_sample(self):
        fake=copy.deepcopy(self.rows)
        fake[0]['city_key']='kyiv'
        with self.assertRaisesRegex(ValueError,'Out-of-scope'):
            sample_site_compatible(fake,aware('2026-10-30T06:11Z'))

    def test_sample_22_site_shape_and_source_labels(self):
        output=sample_site_compatible(self.rows,aware('2026-10-30T06:11Z'))
        self.assertEqual(len(output['cities']),22)
        self.assertTrue(output['meta']['INCOMPLETE_SAMPLE_DO_NOT_DEPLOY'])
        self.assertEqual(output['cities']['sumy']['meta']['source_type'],'raion_proxy')
        self.assertEqual(output['cities']['kharkiv']['meta']['source_type'],'exact_city')
        self.assertEqual(output['cities']['sevastopol']['meta']['source_provenance'],'occupation_administration')
        self.assertEqual(output['cities']['kharkiv']['kpis'],[])

    def test_sample_day_range_completed_only(self):
        output=sample_site_compatible(self.rows,aware('2026-10-30T06:11Z'))
        for c in output['cities'].values():
            self.assertEqual(c['meta']['analysis_end'],'2026-10-29')
            self.assertTrue(all(r['date']<'2026-10-30' for r in c['daily28']))

    def test_csv_utf8_bom_crlf_and_schema(self):
        obj=sample_site_compatible(self.rows,aware('2026-10-30T06:11Z'))
        text=csv_export_daily28(obj)
        self.assertTrue(text.startswith('\ufeffcity_key,date,time,'))
        self.assertIn('\r\n',text)
        self.assertIn('sample_incomplete',text)
        self.assertIn('kharkiv,',text)

    def test_diff_detects_change_and_blocking(self):
        ref={'cities':{},'comparison':{},'all_cities_table':{},'time_of_day_profile':{}}
        for key in CITY_KEYS:
            ref['cities'][key]={'daily28':[{'date':'2026-10-29','alerts_started':1}],
                'weekly':[],'monthly':[],'rolling30':[],'rolling90':[],'kpis':[],
                'meta':{'timezone':'Europe/Kyiv'}}
        other=copy.deepcopy(ref)
        other['cities']['poltava']['daily28'][0]['alerts_started']=2
        diff=diff_rows(ref,other)
        self.assertEqual(diff['total_diff_items'],1)
        self.assertTrue(diff['blocking_details'][0]['known_dst_related'])
        self.assertFalse(diff['production_cutover_allowed'])

    def test_diff_zero_does_not_authorize_cutover(self):
        ref={'cities':{},'comparison':{},'all_cities_table':{},'time_of_day_profile':{}}
        for key in CITY_KEYS:
            ref['cities'][key]={'daily28':[],'weekly':[],'monthly':[],
                'rolling30':[],'rolling90':[],'kpis':[],'meta':{}}
        diff=diff_rows(ref,copy.deepcopy(ref))
        self.assertEqual(diff['total_diff_items'],0)
        self.assertFalse(diff['production_cutover_allowed'])

    def test_physical_union_diagnostics_dst_known(self):
        iv,diag=merged_input_by_city(self.rows)
        self.assertEqual(len(iv),22)
        self.assertTrue(diag['cherkasy']['DST_KNOWN_PROBLEM'])
        self.assertFalse(diag['odesa']['DST_KNOWN_PROBLEM'])

    def test_sql_has_no_mutation_and_is_asof(self):
        lowered=READ_SQL.lower()
        self.assertIn('episode_state = \'closed\'',lowered)
        self.assertIn('created_at <= %s',lowered)
        self.assertIn('end_at <= %s',lowered)
        for token in ['update ', 'delete ', 'insert ', 'drop ', 'create ', 'alter ']:
            self.assertNotIn(token,lowered)


if __name__=='__main__':
    unittest.main()
